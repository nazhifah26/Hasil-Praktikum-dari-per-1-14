<?php

namespace App\Controllers;

class Labvue extends BaseController
{
    public function index()
    {
        return view('labvue_view'); // atau sesuai nama view kamu
    }
}
