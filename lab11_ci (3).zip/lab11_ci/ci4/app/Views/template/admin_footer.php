<footer>
        <p>&copy; 2025 - Universitas Pelita Bangsa</p>
    </footer>
</body>
</html>
